package fr.tntrun;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

/**
 * Géométrie de l'arène : un tube cylindrique creux (contours en tuf)
 * avec 5 étages de sable, 5 blocs de vide entre chaque étage, et de la lave en bas.
 *
 * Offsets verticaux (depuis le Y le plus bas de la sélection) :
 *   0        : fond en tuf
 *   1        : lave
 *   2..6     : vide (5 blocs)
 *   7        : étage 1 (sable)
 *   13,19,25 : étages 2, 3, 4
 *   31       : étage 5 (en haut, là où les joueurs apparaissent)
 *   32..36   : vide + mur de tuf (le tube reste ouvert vers le haut)
 */
public class Arena {

    public static final int FLOORS = 5;
    public static final int GAP = 5;
    public static final int STEP = GAP + 1;
    public static final int FIRST_FLOOR = GAP + 2;                      // 7
    public static final int TOP_FLOOR = FIRST_FLOOR + STEP * (FLOORS - 1); // 31
    public static final int HEIGHT = TOP_FLOOR + GAP + 1;               // 37
    public static final int MIN_SIZE = 9;

    private final World world;
    private final int minX, maxX, minY, minZ, maxZ;
    private final double cx, cz, radius;

    public Arena(Location a, Location b) {
        this.world = a.getWorld();
        this.minX = Math.min(a.getBlockX(), b.getBlockX());
        this.maxX = Math.max(a.getBlockX(), b.getBlockX());
        this.minZ = Math.min(a.getBlockZ(), b.getBlockZ());
        this.maxZ = Math.max(a.getBlockZ(), b.getBlockZ());
        this.minY = Math.min(a.getBlockY(), b.getBlockY());
        this.cx = (minX + maxX + 1) / 2.0;
        this.cz = (minZ + maxZ + 1) / 2.0;
        this.radius = Math.min(width(), depth()) / 2.0;
    }

    public World world() { return world; }
    public int width() { return maxX - minX + 1; }
    public int depth() { return maxZ - minZ + 1; }
    public int minY() { return minY; }
    public double cx() { return cx; }
    public double cz() { return cz; }
    public double radius() { return radius; }

    // ---------- Forme du cylindre ----------

    private boolean inside(int x, int z) {
        double dx = x + 0.5 - cx;
        double dz = z + 0.5 - cz;
        return dx * dx + dz * dz <= radius * radius;
    }

    private boolean isWall(int x, int z) {
        return inside(x, z) && (!inside(x + 1, z) || !inside(x - 1, z) || !inside(x, z + 1) || !inside(x, z - 1));
    }

    private static boolean isFloorOffset(int dy) {
        return dy >= FIRST_FLOOR && dy <= TOP_FLOOR && (dy - FIRST_FLOOR) % STEP == 0;
    }

    // ---------- Construction ----------

    /** Construit entièrement l'arène (murs, fond, lave, étages). */
    public void build() {
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                if (!inside(x, z)) continue;
                boolean wall = isWall(x, z);
                for (int dy = 0; dy < HEIGHT; dy++) {
                    Material m;
                    if (dy == 0 || wall) m = Material.TUFF;
                    else if (dy == 1) m = Material.LAVA;
                    else if (isFloorOffset(dy)) m = Material.SAND;
                    else m = Material.AIR;
                    world.getBlockAt(x, minY + dy, z).setType(m, false);
                }
            }
        }
    }

    /** Remet uniquement les étages de sable (reset entre deux parties). */
    public void resetFloors() {
        for (int k = 0; k < FLOORS; k++) {
            int y = minY + FIRST_FLOOR + STEP * k;
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (inside(x, z) && !isWall(x, z)) {
                        world.getBlockAt(x, y, z).setType(Material.SAND, false);
                    }
                }
            }
        }
    }

    // ---------- Zone / positions ----------

    /**
     * Boîte de la sélection (+ marge), utilisée uniquement pour protéger les blocs
     * (casse / pose interdites pour les joueurs sans permission).
     */
    public boolean inZone(Location l, int margin) {
        if (l.getWorld() == null || !l.getWorld().equals(world)) return false;
        return l.getX() >= minX - margin && l.getX() < maxX + 1 + margin
                && l.getZ() >= minZ - margin && l.getZ() < maxZ + 1 + margin
                && l.getY() >= minY - 1 && l.getY() <= minY + HEIGHT + 10;
    }

    /**
     * Le trou : le disque circulaire à l'intérieur du tube (murs exclus),
     * sous le bord supérieur. C'est ici que le joueur rejoint la partie.
     */
    public boolean inHole(Location l) {
        if (l.getWorld() == null || !l.getWorld().equals(world)) return false;
        double dx = l.getX() - cx;
        double dz = l.getZ() - cz;
        double r = Math.max(1.0, radius - 1.0);
        return dx * dx + dz * dz <= r * r
                && l.getY() >= minY && l.getY() < minY + HEIGHT;
    }

    /** Zone des participants : le cylindre du tube, jusqu'un peu au-dessus du bord. */
    public boolean inTube(Location l) {
        if (l.getWorld() == null || !l.getWorld().equals(world)) return false;
        double dx = l.getX() - cx;
        double dz = l.getZ() - cz;
        double r = radius + 0.5;
        return dx * dx + dz * dz <= r * r
                && l.getY() >= minY - 1 && l.getY() <= minY + HEIGHT + 10;
    }

    /** Point d'apparition des joueurs (étage du haut), 0 ou 1. */
    public Location spawn(int index) {
        double y = minY + TOP_FLOOR + 1;
        if (index == 0) return new Location(world, cx - radius / 2.0, y, cz, -90f, 0f);
        return new Location(world, cx + radius / 2.0, y, cz, 90f, 0f);
    }

    public Location hologramLocation() {
        return new Location(world, cx, minY + HEIGHT + 3, cz);
    }
}
