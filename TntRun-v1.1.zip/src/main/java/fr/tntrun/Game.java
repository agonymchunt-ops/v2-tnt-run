package fr.tntrun;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Display;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class Game implements Listener {

    public enum State { WAITING, STARTING, RUNNING, ENDING }

    private static final int MAX_PLAYERS = 2;

    private final TntRunPlugin plugin;
    private Arena arena;
    private State state = State.WAITING;

    private final List<UUID> players = new ArrayList<>();
    private final Map<UUID, GameMode> previousModes = new HashMap<>();
    private final Map<UUID, Integer> joinCooldown = new HashMap<>();
    /** Blocs de sable en train de se casser -> tick de départ. */
    private final Map<Block, Integer> breaking = new HashMap<>();

    private BukkitTask ticker;
    private BukkitTask countdown;
    private TextDisplay hologram;

    public Game(TntRunPlugin plugin) {
        this.plugin = plugin;
    }

    // =====================================================================
    //  Arène / hologramme
    // =====================================================================

    public void setArena(Arena arena) {
        removeHologram();
        this.arena = arena;
        if (arena != null) updateHologram();
    }

    public boolean isBusy() {
        return !players.isEmpty();
    }

    private void removeHologram() {
        if (hologram != null && hologram.isValid()) hologram.remove();
        hologram = null;
    }

    public void updateHologram() {
        if (arena == null) return;
        int count = players.size();
        Component text = Component.text("Tnt Run", NamedTextColor.GOLD, TextDecoration.BOLD)
                .append(Component.newline())
                .append(Component.text("2 joueurs", NamedTextColor.GRAY))
                .append(Component.newline())
                .append(Component.text(count + "/" + MAX_PLAYERS,
                        count >= MAX_PLAYERS ? NamedTextColor.RED : NamedTextColor.GREEN));

        if (hologram == null || !hologram.isValid()) {
            hologram = arena.world().spawn(arena.hologramLocation(), TextDisplay.class, td -> {
                td.setBillboard(Display.Billboard.CENTER);
                td.setPersistent(false);
                td.setViewRange(2f);
                td.setBackgroundColor(org.bukkit.Color.fromARGB(0, 0, 0, 0));
                td.setTransformation(new Transformation(
                        new Vector3f(), new AxisAngle4f(), new Vector3f(3f, 3f, 3f), new AxisAngle4f()));
            });
        }
        hologram.text(text);
    }

    // =====================================================================
    //  Rejoindre / quitter
    // =====================================================================

    private boolean isParticipant(Player p) {
        return players.contains(p.getUniqueId());
    }

    private Player other(Player p) {
        for (UUID id : players) {
            if (!id.equals(p.getUniqueId())) return Bukkit.getPlayer(id);
        }
        return null;
    }

    private boolean canJoin() {
        return arena != null && state == State.WAITING && players.size() < MAX_PLAYERS;
    }

    /** Utilisé par /tntrun join. */
    public void forceJoin(Player p) {
        if (isParticipant(p)) return;
        if (arena == null) {
            p.sendMessage(Component.text("Aucune arène n'est configurée.", NamedTextColor.RED));
            return;
        }
        if (canJoin()) join(p);
        else p.sendMessage(Component.text("Une partie est déjà en cours.", NamedTextColor.RED));
    }

    private void join(Player p) {
        players.add(p.getUniqueId());
        previousModes.put(p.getUniqueId(), p.getGameMode());
        p.setGameMode(GameMode.ADVENTURE);
        p.setFoodLevel(20);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setVelocity(new Vector());
        p.teleport(arena.spawn(players.size() - 1));
        p.sendMessage(Component.text("Tu as rejoint le TNT Run (" + players.size() + "/" + MAX_PLAYERS + ")", NamedTextColor.GREEN));
        updateHologram();
        if (players.size() == MAX_PLAYERS) startCountdown();
        else p.sendMessage(Component.text("En attente d'un adversaire...", NamedTextColor.GRAY));
    }

    public void leave(Player p) {
        if (!isParticipant(p)) return;
        UUID id = p.getUniqueId();
        switch (state) {
            case WAITING, STARTING -> {
                players.remove(id);
                restore(p);
                cancelCountdown();
                state = State.WAITING;
                for (UUID other : players) {
                    Player r = Bukkit.getPlayer(other);
                    if (r != null) {
                        r.teleport(arena.spawn(0));
                        r.sendMessage(Component.text("Ton adversaire est parti, en attente d'un nouveau joueur...", NamedTextColor.YELLOW));
                    }
                }
                updateHologram();
            }
            case RUNNING -> {
                Player winner = other(p);
                players.remove(id);
                restore(p);
                end(winner, p, "a abandonné");
            }
            case ENDING -> {
                players.remove(id);
                restore(p);
                updateHologram();
            }
        }
    }

    private void restore(Player p) {
        GameMode gm = previousModes.remove(p.getUniqueId());
        p.setGameMode(gm != null ? gm : GameMode.SURVIVAL);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setVelocity(new Vector());
        p.teleport(plugin.lobby());
        joinCooldown.put(p.getUniqueId(), Bukkit.getCurrentTick() + 60);
    }

    // =====================================================================
    //  Déroulement de la partie
    // =====================================================================

    private void startCountdown() {
        state = State.STARTING;
        int[] left = { plugin.getConfig().getInt("countdown-seconds", 5) };
        countdown = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (players.size() < MAX_PLAYERS) {
                cancelCountdown();
                return;
            }
            if (left[0] <= 0) {
                cancelCountdown();
                begin();
                return;
            }
            for (UUID id : players) {
                Player p = Bukkit.getPlayer(id);
                if (p == null) continue;
                p.showTitle(Title.title(Component.text(left[0], NamedTextColor.YELLOW), Component.text("La partie va commencer")));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
            }
            left[0]--;
        }, 0L, 20L);
    }

    private void cancelCountdown() {
        if (countdown != null) countdown.cancel();
        countdown = null;
    }

    private void begin() {
        state = State.RUNNING;
        breaking.clear();
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.showTitle(Title.title(Component.text("GO !", NamedTextColor.GREEN, TextDecoration.BOLD), Component.empty()));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    private void stopTicker() {
        if (ticker != null) ticker.cancel();
        ticker = null;
    }

    /** Exécuté à chaque tick pendant la partie. */
    private void tick() {
        if (state != State.RUNNING) return;
        int now = Bukkit.getCurrentTick();
        int breakTicks = Math.max(2, plugin.getConfig().getInt("sand-break-ticks", 20));

        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Location l = p.getLocation();
            if (l.getBlock().getType() == Material.LAVA) {
                lose(p);
                return;
            }
            trackSand(l, now);
        }

        Iterator<Map.Entry<Block, Integer>> it = breaking.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Block, Integer> en = it.next();
            Block b = en.getKey();
            int elapsed = now - en.getValue();
            Location center = b.getLocation().add(0.5, 0.5, 0.5);
            if (elapsed >= breakTicks) {
                it.remove();
                b.setType(Material.AIR, false);
                b.getWorld().playSound(center, Sound.BLOCK_SAND_BREAK, 0.8f, 1f);
                b.getWorld().spawnParticle(Particle.BLOCK, center, 15, 0.25, 0.25, 0.25, Material.SAND.createBlockData());
            } else if ((now & 1) == 0) {
                float progress = Math.min(1f, elapsed / (float) breakTicks);
                int animId = (b.getX() * 31 + b.getY()) * 31 + b.getZ();
                for (Player viewer : b.getWorld().getNearbyPlayers(center, 48)) {
                    viewer.sendBlockDamage(b.getLocation(), progress, animId);
                }
            }
        }
    }

    /**
     * Démarre la casse des blocs de sable sous le joueur. On regarde jusqu'à 3 blocs
     * sous ses pieds (pas seulement le bloc pile en dessous), pour que le sable se casse
     * aussi quand le joueur saute en boucle (jump / sneak + jump).
     */
    private void trackSand(Location l, int now) {
        double[] offsets = { -0.3, 0.3 };
        int baseY = (int) Math.floor(l.getY() - 0.1);
        for (double dx : offsets) {
            for (double dz : offsets) {
                int bx = (int) Math.floor(l.getX() + dx);
                int bz = (int) Math.floor(l.getZ() + dz);
                for (int k = 0; k <= 2; k++) {
                    Block b = l.getWorld().getBlockAt(bx, baseY - k, bz);
                    Material t = b.getType();
                    if (t == Material.SAND) {
                        if (!breaking.containsKey(b) && arena.inZone(b.getLocation(), 0)) {
                            breaking.put(b, now);
                        }
                        break;
                    }
                    if (!t.isAir()) break; // un bloc solide (tuf, lave...) : on arrête de chercher
                }
            }
        }
    }

    private void lose(Player loser) {
        if (state != State.RUNNING || !isParticipant(loser)) return;
        end(other(loser), loser, "est tombé dans la lave");
    }

    private void end(Player winner, Player loser, String reason) {
        if (state == State.ENDING) return;
        state = State.ENDING;
        stopTicker();
        cancelCountdown();
        breaking.clear();

        String winnerName = winner != null ? winner.getName() : "Personne";
        String loserName = loser != null ? loser.getName() : "L'adversaire";

        Bukkit.broadcast(Component.text("[TNT Run] ", NamedTextColor.GOLD, TextDecoration.BOLD)
                .append(Component.text(winnerName, NamedTextColor.GREEN, TextDecoration.BOLD))
                .append(Component.text(" a gagné la partie ! ", NamedTextColor.YELLOW))
                .append(Component.text("(" + loserName + " " + reason + ")", NamedTextColor.GRAY)));

        if (winner != null) {
            winner.showTitle(Title.title(Component.text("VICTOIRE !", NamedTextColor.GREEN, TextDecoration.BOLD), Component.empty()));
            winner.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        if (loser != null && loser.isOnline()) {
            loser.showTitle(Title.title(Component.text("PERDU", NamedTextColor.RED, TextDecoration.BOLD), Component.empty()));
        }
        Bukkit.getScheduler().runTaskLater(plugin, this::finish, 60L);
    }

    /** Fin de partie : renvoie les joueurs au lobby et remet l'arène à neuf. */
    private void finish() {
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) restore(p);
        }
        players.clear();
        previousModes.clear();
        breaking.clear();
        if (arena != null) arena.resetFloors();
        state = State.WAITING;
        updateHologram();
    }

    /** Remet tout à zéro (/tntrun reset ou arrêt du serveur). */
    public void forceReset() {
        stopTicker();
        cancelCountdown();
        finish();
    }

    public void shutdown() {
        forceReset();
        removeHologram();
    }

    // =====================================================================
    //  Événements
    // =====================================================================

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (arena == null || !e.hasChangedPosition()) return;
        Player p = e.getPlayer();
        Location to = e.getTo();

        if (isParticipant(p)) {
            if (!arena.inTube(to)) leave(p);
            return;
        }

        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (!arena.inHole(to)) return;

        int now = Bukkit.getCurrentTick();
        if (joinCooldown.getOrDefault(p.getUniqueId(), 0) > now) return;

        if (canJoin()) join(p);
        else kickOut(p);
    }

    /** Partie pleine ou en cours : le joueur tombé dans le trou est renvoyé au lobby. */
    private void kickOut(Player p) {
        p.setFallDistance(0f);
        p.setVelocity(new Vector());
        p.teleport(plugin.lobby());
        p.sendActionBar(Component.text("Une partie est en cours, reviens plus tard !", NamedTextColor.RED));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        leave(e.getPlayer());
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && isParticipant(p)) {
            e.setCancelled(true);
            p.setFireTicks(0);
        }
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && isParticipant(p)) e.setCancelled(true);
    }

    /** Sécurité : le sable ne doit jamais tomber en entité. */
    @EventHandler
    public void onFallingBlock(EntityChangeBlockEvent e) {
        if (arena != null && e.getEntity() instanceof FallingBlock && arena.inZone(e.getBlock().getLocation(), 0)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (arena != null && !e.getPlayer().hasPermission("tntrun.admin")
                && arena.inZone(e.getBlock().getLocation(), 0)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (arena != null && !e.getPlayer().hasPermission("tntrun.admin")
                && arena.inZone(e.getBlock().getLocation(), 0)) {
            e.setCancelled(true);
        }
    }
}
