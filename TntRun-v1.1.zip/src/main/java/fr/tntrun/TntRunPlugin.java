package fr.tntrun;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TntRunPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private NamespacedKey toolKey;
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private Game game;
    private Arena arena;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        toolKey = new NamespacedKey(this, "tool");
        game = new Game(this);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(game, this);

        PluginCommand cmd = getCommand("tntrun");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        // On charge l'arène après le chargement des mondes
        getServer().getScheduler().runTask(this, this::loadArena);
    }

    @Override
    public void onDisable() {
        if (game != null) game.shutdown();
    }

    private void loadArena() {
        Location a = getConfig().getLocation("arena.pos1");
        Location b = getConfig().getLocation("arena.pos2");
        if (a != null && b != null && a.getWorld() != null && b.getWorld() != null) {
            arena = new Arena(a, b);
            game.setArena(arena);
            getLogger().info("Arène TNT Run chargée.");
        }
    }

    public Location lobby() {
        Location l = getConfig().getLocation("lobby");
        if (l != null && l.getWorld() != null) return l;
        if (arena != null) return arena.world().getSpawnLocation();
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    // =====================================================================
    //  Outil de sélection
    // =====================================================================

    private ItemStack createTool() {
        ItemStack tool = new ItemStack(Material.BLAZE_ROD);
        tool.editMeta(m -> {
            m.displayName(Component.text("Outil d'arène TNT Run", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            m.lore(List.of(
                    Component.text("Clic gauche : position 1", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("Clic droit : position 2", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
            m.getPersistentDataContainer().set(toolKey, PersistentDataType.BYTE, (byte) 1);
        });
        return tool;
    }

    private boolean isTool(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(toolKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || !isTool(e.getItem())) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("tntrun.admin")) return;
        if (e.getAction() != Action.LEFT_CLICK_BLOCK && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;

        e.setCancelled(true);
        Location loc = e.getClickedBlock().getLocation();
        Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
        int idx = e.getAction() == Action.LEFT_CLICK_BLOCK ? 0 : 1;
        sel[idx] = loc;
        p.sendMessage(Component.text("Position " + (idx + 1) + " définie : "
                + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ(), NamedTextColor.GREEN));
        if (sel[0] != null && sel[1] != null) {
            p.sendMessage(Component.text("Les deux positions sont définies. Fais /tntrun create pour construire l'arène.", NamedTextColor.YELLOW));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onToolBreak(BlockBreakEvent e) {
        if (isTool(e.getPlayer().getInventory().getItemInMainHand())) e.setCancelled(true);
    }

    // =====================================================================
    //  Commandes
    // =====================================================================

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Commande réservée aux joueurs.");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage(Component.text(p.hasPermission("tntrun.admin")
                    ? "/tntrun <tool|create|setlobby|reset|join|leave>"
                    : "/tntrun <join|leave>", NamedTextColor.YELLOW));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "join" -> game.forceJoin(p);
            case "leave" -> game.leave(p);
            case "tool", "create", "setlobby", "reset" -> {
                if (!p.hasPermission("tntrun.admin")) {
                    p.sendMessage(Component.text("Tu n'as pas la permission.", NamedTextColor.RED));
                    return true;
                }
                handleAdmin(p, args[0].toLowerCase());
            }
            default -> p.sendMessage(Component.text(p.hasPermission("tntrun.admin")
                    ? "Sous-commande inconnue."
                    : "Sous-commande inconnue. Utilise /tntrun join ou /tntrun leave.", NamedTextColor.RED));
        }
        return true;
    }

    private void handleAdmin(Player p, String sub) {
        switch (sub) {
            case "tool" -> {
                p.getInventory().addItem(createTool());
                p.sendMessage(Component.text("Outil reçu : clic gauche = position 1, clic droit = position 2.", NamedTextColor.GREEN));
            }
            case "setlobby" -> {
                getConfig().set("lobby", p.getLocation());
                saveConfig();
                p.sendMessage(Component.text("Lobby défini à ta position (là où les joueurs sont renvoyés après une partie).", NamedTextColor.GREEN));
            }
            case "reset" -> {
                game.forceReset();
                if (arena != null) arena.resetFloors();
                p.sendMessage(Component.text("Arène réinitialisée.", NamedTextColor.GREEN));
            }
            case "create" -> createArena(p);
        }
    }

    private void createArena(Player p) {
        Location[] sel = selections.get(p.getUniqueId());
        if (sel == null || sel[0] == null || sel[1] == null) {
            p.sendMessage(Component.text("Définis d'abord les 2 positions avec l'outil (/tntrun tool).", NamedTextColor.RED));
            return;
        }
        if (!sel[0].getWorld().equals(sel[1].getWorld())) {
            p.sendMessage(Component.text("Les deux positions doivent être dans le même monde.", NamedTextColor.RED));
            return;
        }
        if (game.isBusy()) {
            p.sendMessage(Component.text("Impossible : une partie est en cours.", NamedTextColor.RED));
            return;
        }
        Arena a = new Arena(sel[0], sel[1]);
        if (a.width() < Arena.MIN_SIZE || a.depth() < Arena.MIN_SIZE) {
            p.sendMessage(Component.text("Zone trop petite : minimum " + Arena.MIN_SIZE + "x" + Arena.MIN_SIZE
                    + " blocs (actuel : " + a.width() + "x" + a.depth() + ").", NamedTextColor.RED));
            return;
        }
        if (a.minY() < a.world().getMinHeight() || a.minY() + Arena.HEIGHT > a.world().getMaxHeight()) {
            p.sendMessage(Component.text("Pas assez de hauteur : l'arène fait " + Arena.HEIGHT
                    + " blocs de haut à partir du Y le plus bas de ta sélection.", NamedTextColor.RED));
            return;
        }

        a.build();
        arena = a;
        getConfig().set("arena.pos1", sel[0].getBlock().getLocation());
        getConfig().set("arena.pos2", sel[1].getBlock().getLocation());
        saveConfig();
        game.setArena(arena);

        p.sendMessage(Component.text("Arène construite ! (" + a.width() + "x" + a.depth() + ", " + Arena.HEIGHT
                + " blocs de haut). Pense à faire /tntrun setlobby.", NamedTextColor.GREEN));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        List<String> subs = sender.hasPermission("tntrun.admin")
                ? List.of("tool", "create", "setlobby", "reset", "join", "leave")
                : List.of("join", "leave");
        return subs.stream().filter(s -> s.startsWith(args[0].toLowerCase())).toList();
    }
}
